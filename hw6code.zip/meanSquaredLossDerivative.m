function [ value ] = meanSquaredLossDerivative(output,label)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

value = output-label;
end